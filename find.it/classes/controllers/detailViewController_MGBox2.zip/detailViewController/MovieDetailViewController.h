//
//  MovieDetailViewController.h
//  find.it
//
//  Created by dudu on 13-6-24.
//  Copyright (c) 2013年 dudu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DoubanMovieModel.h"
#import "DoubanSearchDelegate.h"

@class MGScrollView;

@interface MovieDetailViewController : UIViewController<DoubanSearchDelegate>

//@property (nonatomic) IBOutlet UILabel *titleLabel;
@property (nonatomic, copy) NSString *movieId;


@property (nonatomic, weak) IBOutlet MGScrollView *scroller;


@end
