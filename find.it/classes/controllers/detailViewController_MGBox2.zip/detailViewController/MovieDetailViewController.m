//
//  MovieDetailViewController.m
//  find.it
//
//  Created by dudu on 13-6-24.
//  Copyright (c) 2013年 dudu. All rights reserved.
//

#import "MovieDetailViewController.h"
#import "AppDelegate.h"
#import "DoubanMovieModel.h"
#import "MGBoxConfigure.h"


#import "MGScrollView.h"
#import "MGLineStyled.h"

#import "MGBox.h"
#import "MGTableBoxStyled.h"    
#import "DoubanRequest.h"

#import "UIImageView+AFNetworking.h"
#import "NSArray+DoubanMovieCasts.h"

#define POST_IMAGE_MARGIN 20
#define IPHONE_TABLES_GRID     (CGSize){320, 0}

#define LINE_DEFAULT_WIDTH 304
#define LINE_DEFAULT_HEIGHT 40
#define LINE_DEFAULT_MARGIN 8

#define STRING_DEFAULT_HEIGHT 30

#define TEXT_COLOR [UIColor colorWithRed:133/256.0 green:192/256.0 blue:201/256.0 alpha:1];
#define BG_COLOR [UIColor colorWithRed:0.94 green:0.94 blue:0.95 alpha:1];
#define NAME_FONT [UIFont fontWithName:@"HelveticaNeue" size:28]



@interface MovieDetailViewController ()
{
    DoubanMovieModel *_movieModel;

}

@property (nonatomic, strong) MGBox *tableGrid;
@property (nonatomic, strong) MGTableBoxStyled *layout;
@property (nonatomic, strong) MGBox *peopleGrid;

@end

@implementation MovieDetailViewController

- (UIImage *)imageBoxLine:(NSString *)imageURL
{
    __block UIImage *returnImage = nil;
    
    UIImageView *imageView = [[UIImageView alloc] init];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:imageURL]];
    UIImage *placeholderImage = [UIImage imageNamed:@"placeholderImage.png"];
    
    [imageView setImageWithURLRequest:request placeholderImage:placeholderImage success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
            returnImage = image;
          });
        
    } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error) {
        NSLog(@"hey buddy, i get an error!");
    }];
    return returnImage;

}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self configureNavigationBar];
    [self configureScrollView];
    [self configureTable];
    [self configureLayout];
    
    
    
    // load movie item
    [self loadMovieModel];
}

- (void)configureLayout
{
    // make the table
    self.layout = MGTableBoxStyled.box;
    [self.tableGrid.boxes addObject:self.layout];
    
    self.peopleGrid = [MGBox boxWithSize:(CGSize){LINE_DEFAULT_WIDTH,0}];
    self.peopleGrid.contentLayoutMode = MGLayoutGridStyle;
    [self.scroller.boxes addObject:self.peopleGrid];
    
}

- (void)configureTable
{
    self.tableGrid = [MGBox boxWithSize:IPHONE_TABLES_GRID];
    self.tableGrid.contentLayoutMode = MGLayoutGridStyle;
    [self.scroller.boxes addObject:self.tableGrid];
    
}
- (void)configureScrollView
{
    // setup the main scroller (using a grid layout)
    self.scroller.contentLayoutMode = MGLayoutGridStyle;
    self.scroller.bottomPadding = 8;
    self.scroller.backgroundColor = BG_COLOR;
}

- (void)configureNavigationBar
{
    // Do any additional setup after loading the view from its nib.
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    //   [appDelegate.navigationController setNavigationBarHidden:NO];
    UINavigationController *nc = appDelegate.navigationController;
    [nc setNavigationBarHidden:NO animated:YES];
    nc.navigationBar.tintColor = [UIColor colorWithRed:.65625 green:.6953125 blue:.66796875 alpha:.1];
}

- (void)viewDidAppear:(BOOL)animated
{
    // @ http://developer.apple.com/library/ios/#releasenotes/General/RN-iOSSDK-6_0/index.html @
    // !!! This is a hack on MGScrollView
    _scroller.translatesAutoresizingMaskIntoConstraints = YES;
    CGSize size = _scroller.frame.size;
    NSLog(@"[view didi appear] width : %f, height : %f", size.width, size.height);
    
    [_scroller setContentSize:size];
    [_scroller setScrollEnabled:YES];
    [_scroller setUserInteractionEnabled:YES];
    
}
#pragma mark - movie box

- (void)addMovieModel
{
    [self initBoxElements];
    
    [self addMovieTitle];
    [self addPeopleInfo];
    [self addGenres];
    [self addCountries];
    [self addPostImage];
    [self addMovieSummary];
    
    [self addCasts];
   
    [self animateBox];
}
- (void)addCasts
{
    
#if 0
    NSArray *casts = _movieModel.casts;
    NSString *castsNames = [casts allCastsNames];
    
    MGBoxLine *castHeader = [MGBoxLine lineWithLeft:@"主演" right:nil];
    MGBoxLine *castLineRight = [MGBoxLine multilineWithText:castsNames font:nil padding:2.0];
//    MGBoxLine *castLine = [MGBoxLine lineWithLeft:nil right:castLineRight];
    [_box.topLines addObject:castHeader];
    [_box.topLines addObject:castLineRight];
#endif
    
}
- (void)addCountries
{
#if 0
    NSString *countriesNames = [_movieModel.countries countriesNames];
    
    MGBoxLine *countriesLine = [MGBoxLine lineWithLeft:@"国家" right:countriesNames];
    
    [_box.topLines addObject:countriesLine];
#endif
}
- (void)addGenres
{
    [self addMGLineStyle:@"类型" withValue:@[@"动作片", @"悬疑片"]];
#if 0
    NSString *genresNames = [_movieModel.genres genresNames];
 
    
    MGBoxLine *genresLine = [MGBoxLine lineWithLeft:@"类型" right:genresNames];

    [_box.topLines addObject:genresLine];
#endif
}

- (void)addPeopleInfo
{
    [self addMGLineStyle:@"导演" withValue:[_movieModel.directors nameArray]];
    
}
- (void)addMovieTitle
{
    CGSize size = (CGSize){LINE_DEFAULT_WIDTH, LINE_DEFAULT_HEIGHT};
    MGLineStyled *titleLine = [MGLineStyled lineWithSize:size];
    titleLine.middleItems = @[_movieModel.title].mutableCopy;
    titleLine.bottomMargin = 8;
    titleLine.font = NAME_FONT;
    [self.layout.topLines addObject:titleLine];
    NSLog(@"####  OOOO ####  %f", titleLine.frame.origin.x);

}

- (void)addMovieSummary
{
#if 0
    id summary = [NSString stringWithFormat:@"简介 : %@", _movieModel.summary];
    MGBoxLine *summaryBoxLine = [MGBoxLine multilineWithText:summary font:nil padding:14];
    [_box.middleLines addObject:summaryBoxLine];
#endif
}

- (void)initBoxElements
{
#if 0
    _box = [MGStyledBox box];
    [_scroller.boxes addObject:_box];
    _scroller.alwaysBounceVertical = YES;
#endif
}

- (void)addPostImage
{

    UIImageView *imageView = [[UIImageView alloc] init];
    NSURLRequest *request = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:_movieModel.imageLarge]];
    UIImage *placeholderImage = [UIImage imageNamed:@"placeholderImage.png"];
     
    [imageView setImageWithURLRequest:request placeholderImage:placeholderImage success:^(NSURLRequest *request, NSHTTPURLResponse *response, UIImage *image) {
 
        dispatch_async(dispatch_get_main_queue(), ^{
#if 0
            NSArray *imgLineLeft = [NSArray arrayWithObjects:image, nil];
            MGBoxLine *imgLine = [MGBoxLine lineWithLeft:imgLineLeft right:nil];

            imgLine.width = image.size.width;
            imgLine.height = image.size.height;
            
            [_box.topLines addObject:imgLine];

            [_scroller drawBoxesWithSpeed:0.6];
            [_scroller flashScrollIndicators];
#endif
        });

    } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error) {
        NSLog(@"hey buddy, i get an error!");
    }];
    
}
- (void)animateBox
{
    [self.tableGrid layout];
    [self.peopleGrid layoutWithSpeed:0.3 completion:nil];
    [self.scroller layoutWithSpeed:0.3 completion:nil];
    [self.scroller scrollToView:self.layout withMargin:8];

}

-(void) viewWillDisappear:(BOOL)animated {
   
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    UINavigationController *navigationController = appDelegate.navigationController;
    if ([navigationController.viewControllers indexOfObject:self] == NSNotFound)
    {
        // back button was pressed.  We know this is true because self is no longer
        // in the navigation stack.
        [navigationController setNavigationBarHidden:YES animated:YES];
        
    }
    [super viewWillDisappear:animated];
}

#pragma mark - load movie model
- (void)loadMovieModel
{
    DoubanRequest *doubanRequest = [[DoubanRequest alloc] init];
    doubanRequest.delegate = self;
    [doubanRequest loadMovieSubject:self.movieId];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES; //显示

    
}
#pragma mark - DoubanSearchDelegate
- (void)loadMovieSubjectFinished:(DoubanMovieModel *)movieModel withError:(NSError *)error
{
    // TODO: hander error
    _movieModel = movieModel;
    NSLog(@"load finished !");
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;

    [self addMovieModel];
    //[self addMovieModel2];
}


#pragma mark - helper functions


- (void)addMGLineStyle:(NSString *)name withValue:(NSArray *)values
{
    int count = [values count];
    NSMutableString *multiLineValue = [[NSMutableString alloc] initWithCapacity:count];
    for (NSString *s in values) {
        [multiLineValue appendFormat:@"%@\n", s];
    }
    NSString *content = [multiLineValue substringToIndex:multiLineValue.length - 1];
    ////////////////////////////////
    // append lines
    ////////////////////////////////
    //    MGLineStyled *nameLine = [MGLineStyled lineWithSize:(CGSize){LINE_DEFAULT_WIDTH/2 -2,LINE_DEFAULT_HEIGHT}];
    MGLineStyled *nameLine = [MGLineStyled lineWithSize:(CGSize){LINE_DEFAULT_WIDTH/2 - 2,  STRING_DEFAULT_HEIGHT*count}];
    nameLine.middleItems = @[name].mutableCopy;
    nameLine.leftMargin = LINE_DEFAULT_MARGIN;
    nameLine.middleTextColor = TEXT_COLOR;
    nameLine.font = NAME_FONT;
    //    dName.padding = UIEdgeInsetsMake(5, 16, 10, 16);
    nameLine.topMargin = 5;
    nameLine.layer.cornerRadius = 8.0;
    nameLine.borderStyle = MGBorderNone;
/*
    MGLineStyled *valueLine = [MGLineStyled lineWithLeft:content right:nil size:(CGSize){LINE_DEFAULT_WIDTH/2 - 2,  STRING_DEFAULT_HEIGHT*count}];
//    valueLine.leftMargin = LINE_DEFAULT_MARGIN;
    //    dValue.padding = UIEdgeInsetsMake(5, 16, 10, 16);
    valueLine.rightMargin = 8;
    valueLine.topMargin = 5;
    valueLine.layer.cornerRadius = 4.0;
  */
    
    MGLineStyled *valueLine = [MGLineStyled lineWithSize:(CGSize){LINE_DEFAULT_WIDTH/2 - 8,  STRING_DEFAULT_HEIGHT*count}];
//    valueLine.contentLayoutMode = MGBoxLayoutAttached;
    valueLine.attachedTo = nameLine;
    valueLine.leftItems = @[content].mutableCopy;
//    valueLine.rightMargin = 8;
    valueLine.layer.cornerRadius = 8.0;
    valueLine.borderStyle = MGBorderNone;
    valueLine.leftMargin = LINE_DEFAULT_MARGIN + LINE_DEFAULT_WIDTH/2; // attached, no need to add 2
    [self.peopleGrid.boxes addObject:nameLine];
    [self.peopleGrid.boxes addObject:valueLine];
    
    [self.peopleGrid layoutWithSpeed:0.3 completion:nil];
}

- (void)viewDidUnload {
    
    [super viewDidUnload];
}
@end
