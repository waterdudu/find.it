//
//  MovieDetailViewController.h
//  find.it
//
//  Created by dudu on 13-6-24.
//  Copyright (c) 2013年 dudu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DoubanBook.h"
#import "DoubanSearchDelegate.h"

@class MGScrollView;

@interface BookDetailViewController : UIViewController<DoubanSearchDelegate>

//@property (nonatomic) IBOutlet UILabel *titleLabel;
@property (nonatomic, copy) NSString *bookId;
@property (nonatomic, strong) DoubanBook *bookModel;


@property (nonatomic, weak) IBOutlet MGScrollView *scroller;
@property (strong, nonatomic) IBOutlet UIImageView *postImageView;
@property (weak, nonatomic) IBOutlet UILabel *authorLabel;
@property (weak, nonatomic) IBOutlet UILabel *publisherLabel;
@property (weak, nonatomic) IBOutlet UILabel *originTitleLabel;
@property (weak, nonatomic) IBOutlet UILabel *translatorLabel;
@property (weak, nonatomic) IBOutlet UILabel *pubdateLabel;
@property (weak, nonatomic) IBOutlet UILabel *pagesLabel;
@property (weak, nonatomic) IBOutlet UILabel *ratingLabel;


@end
