//
//  MovieDetailViewController.m
//  find.it
//
//  Created by dudu on 13-6-24.
//  Copyright (c) 2013年 dudu. All rights reserved.
//

#import "BookDetailViewController.h"
#import "AppDelegate.h"
#import "DoubanMovieModel.h"
#import "MGBoxConfigure.h"


#import "MGScrollView.h"
#import "MGLineStyled.h"

#import "MGBox.h"
#import "MGTableBoxStyled.h"    
#import "DoubanRequest.h"

#import "UIImageView+AFNetworking.h"
#import "NSArray+DoubanMovieCasts.h"

#define POST_IMAGE_MARGIN 20
#define IPHONE_TABLES_GRID     (CGSize){320, 0}

#define LINE_DEFAULT_WIDTH 304
#define LINE_DEFAULT_HEIGHT 40
#define LINE_DEFAULT_MARGIN 8

#define STRING_DEFAULT_HEIGHT 30

#define TEXT_COLOR [UIColor colorWithRed:133/256.0 green:192/256.0 blue:201/256.0 alpha:1];
//#define BG_COLOR [UIColor colorWithRed:0.94 green:0.94 blue:0.95 alpha:1]
#define BG_COLOR [UIColor colorWithRed:240/256.0 green:240/256.0 blue:242/256.0 alpha:1]
#define NAME_FONT [UIFont fontWithName:@"HelveticaNeue" size:28]
#define TEXT_FONT [UIFont fontWithName:@"HelveticaNeue" size:14]
#define NAV_TITLE_FONT [UIFont fontWithName:@"HelveticaNeue" size:18]


#define PLACEHOLDER_IMAGE [UIImage imageNamed:@"placeholderImage.png"]


// adjust the height of a multi-line label to make it align vertical with top



@interface BookDetailViewController ()
{
    DoubanMovieModel *_movieModel;
    UILabel *_myRatingLabel;

}

@property (nonatomic, strong) MGBox *tableGrid;
@property (nonatomic, strong) MGTableBoxStyled *layout;

@end

@implementation BookDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self configureNavigationBar];
    [self configureScrollView];
    [self configureTable];
    [self configureLayout];
    
    // load book item
    [self loadBookModel];

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}
- (void)configureLayout
{
    // make the table
    self.layout = MGTableBoxStyled.box;
    [self.tableGrid.boxes addObject:self.layout];
}

- (void)configureTable
{
    self.tableGrid = [MGBox boxWithSize:IPHONE_TABLES_GRID];
    self.tableGrid.contentLayoutMode = MGLayoutGridStyle;
    [self.scroller.boxes addObject:self.tableGrid];
    
}
- (void)configureScrollView
{
    // setup the main scroller (using a grid layout)
    self.scroller.contentLayoutMode = MGLayoutGridStyle;
    self.scroller.bottomPadding = 8;
    self.scroller.backgroundColor = BG_COLOR;
}

- (void)configureNavigationBar
{
    // Do any additional setup after loading the view from its nib.
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    //   [appDelegate.navigationController setNavigationBarHidden:NO];
    UINavigationController *nc = appDelegate.navigationController;
    [nc setNavigationBarHidden:NO animated:YES];
    // Border
    UIView *navBorder = [[UIView alloc] initWithFrame:CGRectMake(0,nc.navigationBar.frame.size.height-1,nc.navigationBar.frame.size.width, 1)];
    // Change the frame size to suit yours //
    [navBorder setBackgroundColor:BG_COLOR];//[UIColor colorWithWhite:200.0f/255.f alpha:0.8f]];
    [navBorder setOpaque:YES];
    [nc.navigationBar addSubview:navBorder];
    nc.navigationBar.tintColor =  BG_COLOR;//[UIColor clearColor];//[UIColor colorWithRed:.65625 green:.6953125 blue:.66796875 alpha:.1];
//    nc.navigationBar.backgroundColor = BG_COLOR;//[UIColor clearColor];
 //   nc.navigationBar.alpha = 0.0;
//    nc.navigationBar.translucent = YES;
//    nc.navigationBar.opaque = YES;
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    // @ http://developer.apple.com/library/ios/#releasenotes/General/RN-iOSSDK-6_0/index.html @
    // !!! This is a hack on MGScrollView
    _scroller.translatesAutoresizingMaskIntoConstraints = YES;
    CGSize size = _scroller.frame.size;
    NSLog(@"[view didi appear] width : %f, height : %f", size.width, size.height);
    
    [self.scroller setContentSize:size];
    [self.scroller setScrollEnabled:YES];
    [self.scroller setUserInteractionEnabled:YES];
 
//
//    [self adjustRatingLabel];
    
//    self.castsLabel.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    
}
#pragma mark - book box


- (void)addBookSummary
{

    id summary = [NSString stringWithFormat:@"简介 : %@", self.bookModel.summary];
    
    MGLineStyled *line = [MGLineStyled multilineWithText:summary font:TEXT_FONT width:304 padding:UIEdgeInsetsMake(16,16,16,16)];
//    line.topMargin = 200;
//    MGLineStyled *line = [MGLineStyled multilineWithText:summary font:TEXT_FONT width:304                                                 padding:UIEdgeInsetsMake(16, 16, 16, 16)];
    [self.layout.topLines addObject:line];
    
}
- (void)addAuthorIntro
{
    id author_intro = [NSString stringWithFormat:@"作者简介 : %@", self.bookModel.author_intro];
    
    MGLineStyled *line = [MGLineStyled multilineWithText:author_intro font:TEXT_FONT width:304 padding:UIEdgeInsetsMake(16,16,16,16)];
    //    line.topMargin = 200;
    //    MGLineStyled *line = [MGLineStyled multilineWithText:summary font:TEXT_FONT width:304                                                 padding:UIEdgeInsetsMake(16, 16, 16, 16)];
    [self.layout.topLines addObject:line];

}


-(void) viewWillDisappear:(BOOL)animated {
   
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    UINavigationController *navigationController = appDelegate.navigationController;
    if ([navigationController.viewControllers indexOfObject:self] == NSNotFound)
    {
        // back button was pressed.  We know this is true because self is no longer
        // in the navigation stack.
        [navigationController setNavigationBarHidden:YES animated:YES];
        
    }
    [super viewWillDisappear:animated];
}

#pragma mark - load book model
- (void)loadBookModel
{
    // do nothing, use bookmodel
    self.authorLabel.text = [self.bookModel.author arrayToNSString];
    self.publisherLabel.text = self.bookModel.publisher;
    self.originTitleLabel.text = self.bookModel.origin_title;
    self.translatorLabel.text = [self.bookModel.translator arrayToNSString];
    self.pubdateLabel.text = self.bookModel.pubdate;
    self.pagesLabel.text = self.bookModel.pages;
    
    self.ratingLabel.text = [NSString stringWithFormat:@"%.1f", self.bookModel.rating.average];
    
    
    NSURL *url = [NSURL URLWithString:self.bookModel.imageLarge];
    [self.postImageView setImageWithURL:url placeholderImage:PLACEHOLDER_IMAGE];
    
    ////////////////////////////////////////
    //  add summary
    ////////////////////////////////////////
    
    [self addBookSummary];
    [self addAuthorIntro];
    [self animateBox];
    
    
    ////////////////////////////////////////
    // change title
    ////////////////////////////////////////
    AppDelegate *appDelegate = [UIApplication sharedApplication].delegate;
    // change navigation controller's title
    UINavigationController *nc = appDelegate.navigationController;
    nc.title = _movieModel.title;
    
    UILabel *navLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 302 - 80, 80)];
    navLabel.backgroundColor = [UIColor clearColor];
    navLabel.textColor = [UIColor blackColor];
    navLabel.shadowColor = [UIColor colorWithWhite:0.0 alpha:0.5];
    navLabel.font = NAV_TITLE_FONT;
    navLabel.textAlignment = UITextAlignmentCenter;
    navLabel.center = nc.navigationItem.titleView.center;
    navLabel.text = self.bookModel.title;
    
    self.navigationItem.titleView = navLabel;

    
}

- (void)animateBox
{
    [self.tableGrid layout];
    [self.scroller layoutWithSpeed:0.3 completion:nil];
    [self.scroller scrollToView:self.layout withMargin:8];
}


- (void)viewDidUnload {
    
    [self setPostImageView:nil];
    [self setRatingLabel:nil];
    [self setAuthorLabel:nil];
    [self setPublisherLabel:nil];
    [self setOriginTitleLabel:nil];
    [self setTranslatorLabel:nil];
    [self setPubdateLabel:nil];
    [self setPagesLabel:nil];
    [self setRatingLabel:nil];
    [super viewDidUnload];
}
@end
